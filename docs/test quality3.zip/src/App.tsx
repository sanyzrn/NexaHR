import { useMemo, useState } from "react";
import { cn } from "./utils/cn";
import {
  couldNotCheck,
  findings,
  meta,
  methodology,
  verdict,
  verifiedCorrect,
  type Finding,
  type Severity,
} from "./data/report";

const SEVERITY_ORDER: Severity[] = ["HIGH", "MEDIUM", "LOW"];

const severityStyles: Record<Severity, { badge: string; ring: string; dot: string; text: string }> = {
  HIGH: {
    badge: "bg-rose-600 text-white",
    ring: "border-rose-300 dark:border-rose-800",
    dot: "bg-rose-500",
    text: "text-rose-700 dark:text-rose-300",
  },
  MEDIUM: {
    badge: "bg-amber-500 text-slate-950",
    ring: "border-amber-300 dark:border-amber-800",
    dot: "bg-amber-400",
    text: "text-amber-700 dark:text-amber-300",
  },
  LOW: {
    badge: "bg-sky-600 text-white",
    ring: "border-sky-300 dark:border-sky-800",
    dot: "bg-sky-500",
    text: "text-sky-700 dark:text-sky-300",
  },
};

const statusStyles: Record<Finding["status"], string> = {
  "VERIFIED (source read)":
    "bg-emerald-100 text-emerald-800 dark:bg-emerald-900/40 dark:text-emerald-200 border-emerald-300 dark:border-emerald-700",
  "PARTIALLY VERIFIED":
    "bg-amber-100 text-amber-900 dark:bg-amber-900/40 dark:text-amber-200 border-amber-300 dark:border-amber-700",
  UNVERIFIED:
    "bg-slate-200 text-slate-800 dark:bg-slate-700 dark:text-slate-100 border-slate-300 dark:border-slate-600",
};

const NAV = [
  { id: "verdict", label: "Verdict" },
  { id: "findings", label: "Findings" },
  { id: "verified", label: "Verified correct" },
  { id: "could-not-check", label: "Could not check" },
  { id: "method", label: "Method & limits" },
];

function SectionHeading({
  id,
  number,
  title,
  subtitle,
}: {
  id: string;
  number: string;
  title: string;
  subtitle?: string;
}) {
  return (
    <div id={id} className="scroll-mt-24 mb-6">
      <div className="flex items-baseline gap-3">
        <span className="font-mono text-xs tracking-widest text-slate-400">{number}</span>
        <h2 className="text-2xl sm:text-3xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
          {title}
        </h2>
      </div>
      {subtitle && <p className="mt-2 text-sm text-slate-500 dark:text-slate-400 max-w-3xl">{subtitle}</p>}
    </div>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <div className="text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400 mb-1.5">
      {children}
    </div>
  );
}

function Prose({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <p className={cn("text-[15px] leading-relaxed text-slate-700 dark:text-slate-300 break-words", className)}>
      {children}
    </p>
  );
}

function FindingCard({ finding, index }: { finding: Finding; index: number }) {
  const [open, setOpen] = useState(index < 3);
  const s = severityStyles[finding.severity];
  return (
    <article
      id={finding.id}
      className={cn(
        "scroll-mt-24 rounded-2xl border bg-white/80 dark:bg-slate-900/60 backdrop-blur shadow-sm",
        s.ring,
      )}
    >
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="w-full text-left px-5 sm:px-6 py-5 flex items-start gap-4"
      >
        <div className="flex flex-col items-center gap-2 pt-0.5 shrink-0">
          <span className={cn("rounded-md px-2 py-0.5 text-[11px] font-bold tracking-wider", s.badge)}>
            {finding.severity}
          </span>
          <span className="font-mono text-xs text-slate-400">{finding.id}</span>
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="text-base sm:text-lg font-semibold leading-snug text-slate-900 dark:text-slate-50">
            {finding.title}
          </h3>
          <div className="mt-2 flex flex-wrap items-center gap-2">
            <span
              className={cn(
                "rounded-full border px-2.5 py-0.5 text-[11px] font-medium",
                statusStyles[finding.status],
              )}
            >
              {finding.status}
            </span>
            <span className="font-mono text-[11px] text-slate-500 dark:text-slate-400 truncate max-w-full">
              {finding.location.split(" · ")[0]}
            </span>
          </div>
        </div>
        <svg
          className={cn(
            "mt-1 h-5 w-5 shrink-0 text-slate-400 transition-transform",
            open && "rotate-180",
          )}
          viewBox="0 0 20 20"
          fill="currentColor"
          aria-hidden
        >
          <path
            fillRule="evenodd"
            d="M5.23 7.21a.75.75 0 011.06.02L10 11.17l3.71-3.94a.75.75 0 111.08 1.04l-4.25 4.5a.75.75 0 01-1.08 0l-4.25-4.5a.75.75 0 01.02-1.06z"
            clipRule="evenodd"
          />
        </svg>
      </button>

      {open && (
        <div className="px-5 sm:px-6 pb-6 pt-1 border-t border-slate-200/70 dark:border-slate-800 space-y-5">
          <div>
            <Label>file:line</Label>
            <ul className="space-y-1">
              {finding.location.split(" · ").map((loc) => (
                <li
                  key={loc}
                  className="font-mono text-[12.5px] leading-relaxed text-slate-800 dark:text-slate-200 bg-slate-100 dark:bg-slate-800/70 rounded-md px-2.5 py-1.5 break-words"
                >
                  {loc}
                </li>
              ))}
            </ul>
          </div>

          <div className="grid gap-5 lg:grid-cols-2">
            <div>
              <Label>What breaks</Label>
              <Prose>{finding.whatBreaks}</Prose>
            </div>
            <div>
              <Label>How to reach it (role · inputs · state → wrong result)</Label>
              <Prose>{finding.howToReach}</Prose>
            </div>
          </div>

          <div className={cn("rounded-xl border p-4", s.ring, "bg-slate-50/70 dark:bg-slate-950/40")}>
            <Label>
              <span className={s.text}>Mutation the suite would not catch</span>
            </Label>
            <Prose className="font-medium">{finding.mutation}</Prose>
          </div>

          <div>
            <Label>Evidence</Label>
            <ul className="space-y-2">
              {finding.evidence.map((e, i) => (
                <li key={i} className="flex gap-2.5">
                  <span className={cn("mt-2 h-1.5 w-1.5 rounded-full shrink-0", s.dot)} />
                  <code className="text-[12.5px] leading-relaxed text-slate-700 dark:text-slate-300 whitespace-pre-wrap break-words">
                    {e}
                  </code>
                </li>
              ))}
            </ul>
          </div>

          <div className="rounded-xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-900 p-4">
            <Label>
              <span className="text-emerald-700 dark:text-emerald-300">Fix</span>
            </Label>
            <Prose>{finding.fix}</Prose>
          </div>
        </div>
      )}
    </article>
  );
}

export default function App() {
  const [filter, setFilter] = useState<Severity | "ALL">("ALL");

  const counts = useMemo(() => {
    const c: Record<Severity, number> = { HIGH: 0, MEDIUM: 0, LOW: 0 };
    for (const f of findings) c[f.severity] += 1;
    return c;
  }, []);

  const visible = useMemo(
    () => (filter === "ALL" ? findings : findings.filter((f) => f.severity === filter)),
    [filter],
  );

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-950 dark:to-slate-900 text-slate-900 dark:text-slate-100">
      {/* Top bar */}
      <header className="sticky top-0 z-30 border-b border-slate-200/80 dark:border-slate-800 bg-white/80 dark:bg-slate-950/80 backdrop-blur">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 h-14 flex items-center justify-between gap-4">
          <a href="#top" className="flex items-center gap-2.5 min-w-0">
            <span className="h-2.5 w-2.5 rounded-sm bg-rose-500 shadow-[0_0_0_3px_rgba(244,63,94,0.2)]" />
            <span className="font-semibold tracking-tight truncate">NexaHR · Test-Quality Audit</span>
          </a>
          <nav className="hidden md:flex items-center gap-1 text-sm">
            {NAV.map((n) => (
              <a
                key={n.id}
                href={`#${n.id}`}
                className="px-3 py-1.5 rounded-md text-slate-600 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800 hover:text-slate-900 dark:hover:text-white"
              >
                {n.label}
              </a>
            ))}
          </nav>
        </div>
      </header>

      <main id="top" className="mx-auto max-w-6xl px-4 sm:px-6 pb-24">
        {/* Hero */}
        <section className="pt-12 sm:pt-16 pb-10">
          <div className="flex flex-wrap items-center gap-2 text-xs font-mono text-slate-500 dark:text-slate-400">
            <span className="rounded bg-slate-200/70 dark:bg-slate-800 px-2 py-0.5">{meta.repo.replace("https://", "")}</span>
            <span className="rounded bg-slate-200/70 dark:bg-slate-800 px-2 py-0.5">branch: {meta.branch}</span>
            <span className="rounded bg-slate-200/70 dark:bg-slate-800 px-2 py-0.5">commit: {meta.commit.slice(0, 12)}</span>
            <span className="rounded bg-slate-200/70 dark:bg-slate-800 px-2 py-0.5">angle: {meta.angle}</span>
          </div>
          <h1 className="mt-5 text-4xl sm:text-5xl font-semibold tracking-tight leading-[1.1]">
            Tests that cannot fail,
            <br className="hidden sm:block" /> and the paths nothing tests.
          </h1>
          <p className="mt-4 max-w-3xl text-base sm:text-lg text-slate-600 dark:text-slate-300">
            A review of the NexaHR test suite — {meta.scope}. Each finding names the file and line, what breaks, a
            concrete path to reach it, the source mutation the suite would not catch, and the fix.
          </p>

          <div className="mt-6 flex flex-wrap gap-3">
            <div className="rounded-xl border border-rose-300 dark:border-rose-900 bg-rose-50 dark:bg-rose-950/40 px-4 py-2.5 text-sm">
              <span className="font-bold text-rose-700 dark:text-rose-300">Not executed.</span>{" "}
              <span className="text-rose-900/80 dark:text-rose-200/80">
                No shell, checkout or PostgreSQL was available; <code className="font-mono">scripts/ci-local.sh</code> did not
                run. All claims are source reads, labelled per finding.
              </span>
            </div>
          </div>

          {/* Stats */}
          <div className="mt-8 grid grid-cols-2 sm:grid-cols-4 gap-3">
            {[
              { label: "Findings", value: findings.length, sub: "ranked, capped at 10" },
              { label: "High", value: counts.HIGH, sub: "official document / concurrency / copilot" },
              { label: "Medium", value: counts.MEDIUM, sub: "state, defaults, coverage gaps" },
              { label: "Low", value: counts.LOW, sub: "CI, frontend rows" },
            ].map((s) => (
              <div
                key={s.label}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/60 p-4"
              >
                <div className="text-3xl font-semibold tabular-nums">{s.value}</div>
                <div className="text-sm font-medium mt-1">{s.label}</div>
                <div className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">{s.sub}</div>
              </div>
            ))}
          </div>
        </section>

        {/* Verdict */}
        <section className="py-10 border-t border-slate-200 dark:border-slate-800">
          <SectionHeading id="verdict" number="01" title="Verdict" subtitle="Three lines." />
          <ol className="space-y-4">
            {verdict.map((line, i) => (
              <li
                key={i}
                className="flex gap-4 rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/60 p-5"
              >
                <span className="font-mono text-sm text-slate-400 pt-0.5">{i + 1}</span>
                <p className="text-[15.5px] leading-relaxed text-slate-800 dark:text-slate-200">{line}</p>
              </li>
            ))}
          </ol>
        </section>

        {/* Findings */}
        <section className="py-10 border-t border-slate-200 dark:border-slate-800">
          <SectionHeading
            id="findings"
            number="02"
            title="Findings"
            subtitle="severity | file:line | what breaks | how to reach it | mutation not caught | fix. Ranked by severity; ten, no maybes. Items flagged PARTIALLY VERIFIED name exactly which half was read."
          />

          <div className="mb-6 flex flex-wrap items-center gap-2">
            {(["ALL", ...SEVERITY_ORDER] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setFilter(s)}
                className={cn(
                  "rounded-full border px-3.5 py-1.5 text-sm font-medium transition",
                  filter === s
                    ? "bg-slate-900 text-white border-slate-900 dark:bg-white dark:text-slate-900 dark:border-white"
                    : "border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 hover:bg-slate-100 dark:hover:bg-slate-800",
                )}
              >
                {s === "ALL" ? `All (${findings.length})` : `${s} (${counts[s]})`}
              </button>
            ))}
          </div>

          {/* Index table */}
          <div className="mb-8 overflow-x-auto rounded-2xl border border-slate-200 dark:border-slate-800">
            <table className="w-full text-sm">
              <thead className="bg-slate-100/80 dark:bg-slate-900 text-left text-xs uppercase tracking-wider text-slate-500 dark:text-slate-400">
                <tr>
                  <th className="px-4 py-3 font-semibold">#</th>
                  <th className="px-4 py-3 font-semibold">Severity</th>
                  <th className="px-4 py-3 font-semibold">Finding</th>
                  <th className="px-4 py-3 font-semibold hidden md:table-cell">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800 bg-white/60 dark:bg-slate-950/40">
                {visible.map((f) => (
                  <tr key={f.id} className="hover:bg-slate-50 dark:hover:bg-slate-900/60">
                    <td className="px-4 py-3 font-mono text-xs text-slate-500">{f.id}</td>
                    <td className="px-4 py-3">
                      <span
                        className={cn(
                          "rounded-md px-2 py-0.5 text-[11px] font-bold tracking-wider",
                          severityStyles[f.severity].badge,
                        )}
                      >
                        {f.severity}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <a href={`#${f.id}`} className="hover:underline text-slate-900 dark:text-slate-100">
                        {f.title}
                      </a>
                    </td>
                    <td className="px-4 py-3 hidden md:table-cell">
                      <span className={cn("rounded-full border px-2 py-0.5 text-[11px]", statusStyles[f.status])}>
                        {f.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="space-y-5">
            {visible.map((f, i) => (
              <FindingCard key={f.id} finding={f} index={i} />
            ))}
          </div>
        </section>

        {/* Verified correct */}
        <section className="py-10 border-t border-slate-200 dark:border-slate-800">
          <SectionHeading
            id="verified"
            number="03"
            title="Verified correct"
            subtitle="Risky areas that were checked and found sound — as read in source, not executed."
          />
          <div className="grid gap-4 md:grid-cols-2">
            {verifiedCorrect.map((v) => (
              <div
                key={v.area}
                className="rounded-2xl border border-emerald-200 dark:border-emerald-900/70 bg-emerald-50/50 dark:bg-emerald-950/20 p-5"
              >
                <div className="flex items-center gap-2 mb-2">
                  <svg className="h-4 w-4 text-emerald-600 dark:text-emerald-400" viewBox="0 0 20 20" fill="currentColor" aria-hidden>
                    <path
                      fillRule="evenodd"
                      d="M16.704 5.29a1 1 0 010 1.42l-7.5 7.5a1 1 0 01-1.42 0l-3.5-3.5a1 1 0 111.42-1.42l2.79 2.8 6.79-6.8a1 1 0 011.42 0z"
                      clipRule="evenodd"
                    />
                  </svg>
                  <h3 className="font-semibold text-slate-900 dark:text-slate-50">{v.area}</h3>
                </div>
                <p className="text-[14.5px] leading-relaxed text-slate-700 dark:text-slate-300 break-words">{v.detail}</p>
              </div>
            ))}
          </div>
        </section>

        {/* Could not check */}
        <section className="py-10 border-t border-slate-200 dark:border-slate-800">
          <SectionHeading
            id="could-not-check"
            number="04"
            title="Could not check, and why"
            subtitle="Everything below is UNVERIFIED. Listed so nothing above is mistaken for more than it is."
          />
          <ul className="space-y-3">
            {couldNotCheck.map((c) => (
              <li
                key={c.item}
                className="rounded-2xl border border-slate-200 dark:border-slate-800 bg-white/70 dark:bg-slate-900/60 p-5"
              >
                <div className="flex items-start gap-3">
                  <span className="mt-1 rounded bg-slate-200 dark:bg-slate-700 px-1.5 py-0.5 text-[10px] font-bold tracking-wider text-slate-700 dark:text-slate-200">
                    UNVERIFIED
                  </span>
                  <div className="min-w-0">
                    <div className="font-medium text-slate-900 dark:text-slate-50 break-words">{c.item}</div>
                    <p className="mt-1 text-[14.5px] leading-relaxed text-slate-600 dark:text-slate-400 break-words">{c.why}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </section>

        {/* Method */}
        <section className="py-10 border-t border-slate-200 dark:border-slate-800">
          <SectionHeading id="method" number="—" title="Method & limits" subtitle="How the source was read, so the labels above can be audited." />
          <ul className="space-y-2">
            {methodology.map((m, i) => (
              <li key={i} className="flex gap-3 text-[14.5px] leading-relaxed text-slate-700 dark:text-slate-300">
                <span className="mt-2.5 h-1.5 w-1.5 rounded-full bg-slate-400 shrink-0" />
                <span className="break-words">{m}</span>
              </li>
            ))}
          </ul>
        </section>
      </main>

      <footer className="border-t border-slate-200 dark:border-slate-800">
        <div className="mx-auto max-w-6xl px-4 sm:px-6 py-6 text-xs text-slate-500 dark:text-slate-400 flex flex-wrap justify-between gap-2">
          <span>
            NexaHR test-quality audit · {meta.repo} @ {meta.commit.slice(0, 12)}
          </span>
          <span>Persian identifiers and comments are quoted verbatim and are not findings.</span>
        </div>
      </footer>
    </div>
  );
}
